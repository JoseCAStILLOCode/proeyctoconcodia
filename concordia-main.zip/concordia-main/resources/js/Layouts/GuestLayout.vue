<template>
    <div class="flex h-screen items-center justify-center bg-gray-200 px-6">
        <div class="w-full max-w-sm rounded-md bg-white p-6 shadow-md">
            <slot />
        </div>
    </div>
</template>
